### Search and Sort classes

Different Search and Sort algorithms
are implemented.
For more informations visit:
https://github.com/m1ghtfr3e/SearchSort
